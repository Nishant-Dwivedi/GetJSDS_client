# GetJSDS_client

GetJSDS is an extension that fetches some commonly used data structures that are unavailable in Javascript from a server, and copies them to the clipboard.
